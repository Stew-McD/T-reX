# WasteAndMaterialFootprint
A program for Life Cycle Assessment (LCA) calculations of supply chain waste and material footprints.

Soon to be a paper, hopefully.

Also, documentation is coming soon.
